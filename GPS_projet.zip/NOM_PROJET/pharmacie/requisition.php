<?php
require_once '../config/config.php';
require_once '../config/database.php';
requireLogin();
if (!hasPermission('pharmacie')) redirect('../index.php');

$database = new Database();
$db = $database->getConnection();

$idofficine = $_GET['idofficine'] ?? null;
if (!$idofficine) redirect('officine.php');

$stmt_off = $db->prepare("SELECT * FROM officine WHERE idofficine = :id");
$stmt_off->bindParam(':id', $idofficine);
$stmt_off->execute();
$officine = $stmt_off->fetch();

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['creer_requisition'])) {
    $produits  = $_POST['produits']  ?? [];
    $quantites = $_POST['quantites'] ?? [];

    if (empty($produits)) {
        $error = "Veuillez sélectionner au moins un produit.";
    } else {
        try {
            $db->beginTransaction();

            $query_num = "SELECT MAX(CAST(SUBSTRING(numero_requisition, 4) AS UNSIGNED)) AS last_num
                          FROM requisition WHERE numero_requisition LIKE 'REQ%'";
            $row_num   = $db->query($query_num)->fetch();
            $numero_requisition = generateNumero('REQ', $row_num['last_num'] ?? 0);

            $stmt = $db->prepare("INSERT INTO requisition (idofficine, numero_requisition, idutilisateur)
                                  VALUES (:idofficine, :numero_requisition, :idutilisateur)");
            $stmt->execute([
                ':idofficine'         => $idofficine,
                ':numero_requisition' => $numero_requisition,
                ':idutilisateur'      => $_SESSION['user_id'],
            ]);
            $idrequisition = $db->lastInsertId();

            $stmt_ligne = $db->prepare("INSERT INTO lignesrecquisition (idrequisition, idprodpharma, quantite_demandee)
                                        VALUES (:idrequisition, :idprodpharma, :quantite)");
            foreach ($produits as $index => $idprodpharma) {
                if (!empty($idprodpharma) && !empty($quantites[$index]) && $quantites[$index] > 0) {
                    $stmt_ligne->execute([
                        ':idrequisition' => $idrequisition,
                        ':idprodpharma'  => $idprodpharma,
                        ':quantite'      => $quantites[$index],
                    ]);
                }
            }

            $db->commit();
            $success = "Réquisition créée avec succès ! N° : " . $numero_requisition;
        } catch (Exception $e) {
            $db->rollBack();
            $error = "Erreur : " . $e->getMessage();
        }
    }
}

$query_hist = "SELECT r.*, u.nom AS user_nom, u.prenom AS user_prenom
               FROM requisition r JOIN utilisateur u ON r.idutilisateur = u.idutilisateur
               WHERE r.idofficine = :idofficine ORDER BY r.date_requisition DESC LIMIT 20";
$stmt_hist  = $db->prepare($query_hist);
$stmt_hist->bindParam(':idofficine', $idofficine);
$stmt_hist->execute();
$historique = $stmt_hist->fetchAll();

$pageTitle = "Réquisition - " . APP_NAME;
include '../views/includes/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-file-import"></i> Nouvelle Réquisition</h1>
    <a href="stock-officine.php?idofficine=<?php echo $idofficine; ?>" class="btn btn-outline">
        <i class="fas fa-arrow-left"></i> Retour au stock
    </a>
</div>

<div class="officine-info">
    <strong>Officine :</strong> <?php echo htmlspecialchars($officine['nom']); ?>
</div>

<?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3 class="card-title">Produits à Réquisitionner</h3></div>
    <div class="card-body">
        <form method="POST">
            <div id="produitsContainer">
                <div class="produit-ligne">
                    <div class="form-row">
                        <div class="form-group" style="flex:2">
                            <label>Produit</label>
                            <select name="produits[]" class="form-control produit-select" required>
                                <option value="">-- Sélectionner un produit --</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Quantité</label>
                            <input type="number" name="quantites[]" class="form-control" min="1" required>
                        </div>
                        <div class="form-group" style="align-self:flex-end">
                            <button type="button" class="btn btn-danger btn-sm" onclick="removeLigne(this)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-actions mt-2" style="justify-content:flex-start;gap:10px;">
                <button type="button" class="btn btn-secondary" onclick="addLigne()">
                    <i class="fas fa-plus"></i> Ajouter un produit
                </button>
                <button type="submit" name="creer_requisition" class="btn btn-primary btn-lg">
                    <i class="fas fa-paper-plane"></i> Envoyer la Réquisition
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-2">
    <div class="card-header"><h3 class="card-title">Historique des Réquisitions</h3></div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr><th>N° Réquisition</th><th>Date</th><th>Demandé par</th><th>Statut</th><th>Date Traitement</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($historique as $req): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($req['numero_requisition']); ?></strong></td>
                        <td><?php echo formatDateTime($req['date_requisition']); ?></td>
                        <td><?php echo htmlspecialchars($req['user_prenom'] . ' ' . $req['user_nom']); ?></td>
                        <td>
                            <?php $bc = ['en_attente'=>'badge-warning','servi'=>'badge-success','refuse'=>'badge-danger'][$req['statut']] ?? 'badge-secondary'; ?>
                            <span class="badge <?php echo $bc; ?>"><?php echo ucfirst(str_replace('_',' ',$req['statut'])); ?></span>
                        </td>
                        <td><?php echo $req['date_traitement'] ? formatDateTime($req['date_traitement']) : '-'; ?></td>
                        <td>
                            <a href="detail-requisition.php?id=<?php echo $req['idrequisition']; ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-eye"></i> Voir
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.produit-ligne { margin-bottom:15px;padding:15px;background:var(--light);border-radius:8px; }
.officine-info { background:white;padding:15px 20px;border-radius:8px;box-shadow:var(--shadow);margin:20px 0;font-size:16px; }
.officine-info strong { color:var(--primary); }
</style>

<script>
let produits = [];

fetch('../api/get-produits-pharma.php?idofficine=<?php echo $idofficine; ?>')
    .then(r => r.json())
    .then(data => { produits = data; updateAllSelects(); })
    .catch(e => console.log('API produits non disponible'));

function updateAllSelects() {
    document.querySelectorAll('.produit-select').forEach(s => updateSelect(s));
}
function updateSelect(select) {
    const cur = select.value;
    let html = '<option value="">-- Sélectionner un produit --</option>';
    produits.forEach(p => {
        html += `<option value="${p.idprodpharma}">${p.libelle} - ${p.code} (Stock: ${p.stock_disponible})</option>`;
    });
    select.innerHTML = html;
    if (cur) select.value = cur;
}
function addLigne() {
    const c = document.getElementById('produitsContainer');
    const n = c.firstElementChild.cloneNode(true);
    n.querySelectorAll('input,select').forEach(i => i.value = '');
    c.appendChild(n);
    updateAllSelects();
}
function removeLigne(btn) {
    const c = document.getElementById('produitsContainer');
    if (c.children.length > 1) btn.closest('.produit-ligne').remove();
    else alert('Au moins un produit doit être conservé.');
}
</script>

<?php include '../views/includes/footer.php'; ?>
