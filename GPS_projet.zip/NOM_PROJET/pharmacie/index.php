<?php
require_once '../config/config.php';
requireLogin();
if (!hasPermission('pharmacie')) redirect('../index.php');

$pageTitle = "Pharmacie - " . APP_NAME;
include '../views/includes/header.php';
?>
<div class="pharmacie-module">
    <div class="module-header">
        <h1><i class="fas fa-pills"></i> Module Pharmacie</h1>
        <p>Gestion du stock et des prescriptions</p>
    </div>
    <div class="action-cards">
        <a href="officine.php" class="action-card">
            <div class="action-icon"><i class="fas fa-store"></i></div>
            <h3>Officine</h3>
            <p>Traitement des prescriptions</p>
        </a>
        <a href="depot-central.php" class="action-card">
            <div class="action-icon"><i class="fas fa-warehouse"></i></div>
            <h3>Dépôt Central</h3>
            <p>Gestion du stock principal</p>
        </a>
        <a href="produits.php" class="action-card">
            <div class="action-icon"><i class="fas fa-pills"></i></div>
            <h3>Produits</h3>
            <p>Fiches des produits pharmaceutiques</p>
        </a>
        <a href="rapports.php" class="action-card">
            <div class="action-icon"><i class="fas fa-chart-bar"></i></div>
            <h3>Rapports</h3>
            <p>Statistiques et consommation</p>
        </a>
    </div>
</div>
<?php include '../views/includes/footer.php'; ?>
