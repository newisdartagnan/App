<?php
require_once '../config/config.php';
require_once '../config/database.php';
requireLogin();
if (!hasPermission('pharmacie')) redirect('../index.php');

$database = new Database();
$db = $database->getConnection();

$idpharma_presc = $_GET['id'] ?? null;
if (!$idpharma_presc) redirect('officine.php');

$query = "SELECT pp.*,
                 pr.libelle AS produit_libelle, pr.code AS produit_code,
                 p.nom AS patient_nom, p.prenom AS patient_prenom,
                 u.nom AS prescripteur_nom,
                 sp.quantite AS stock_disponible
          FROM pharma_presc pp
          JOIN prodpharma  pr ON pp.idprodpharma = pr.idprodpharma
          JOIN sous_sejour ss ON pp.idsous_sejour = ss.idsous_sejour
          JOIN sejour      s  ON ss.idsejour      = s.idsejour
          JOIN patient     p  ON s.idpatient      = p.idpatient
          LEFT JOIN utilisateur u ON pp.prescripteur = u.idutilisateur
          LEFT JOIN stockpharma sp ON pr.idprodpharma = sp.idprodpharma
              AND sp.idofficine = (SELECT idofficine FROM officine WHERE idsite = s.idsite LIMIT 1)
          WHERE pp.idpharma_presc = :id";

$stmt = $db->prepare($query);
$stmt->bindParam(':id', $idpharma_presc);
$stmt->execute();
$presc = $stmt->fetch();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['achever'])) {
    try {
        $db->beginTransaction();

        $stock_dispo = $presc['stock_disponible'] ?? 0;
        if ($stock_dispo < $presc['quantite']) {
            throw new Exception("Stock insuffisant ! Disponible: {$stock_dispo}, Demandé: {$presc['quantite']}");
        }

        // Déduire du stock
        $db->prepare("UPDATE stockpharma SET quantite = quantite - :q
                      WHERE idprodpharma = :idp
                      AND idofficine = (SELECT idofficine FROM officine WHERE idsite = :ids LIMIT 1)")
           ->execute([':q' => $presc['quantite'], ':idp' => $presc['idprodpharma'], ':ids' => $_SESSION['site_id']]);

        // MAJ prescription
        $db->prepare("UPDATE pharma_presc SET statut_execution='acheve', date_execution=NOW(), executeur=:ex
                      WHERE idpharma_presc=:id")
           ->execute([':ex' => $_SESSION['user_id'], ':id' => $idpharma_presc]);

        $db->commit();

        // Notification prescripteur
        try {
            $db->prepare("INSERT INTO msg (idutilisateur, message, date_envoi, lu) VALUES (:uid, :msg, NOW(), 0)")
               ->execute([
                   ':uid' => $presc['prescripteur'] ?? 0,
                   ':msg' => "Médicament '{$presc['produit_libelle']}' délivré pour {$presc['patient_prenom']} {$presc['patient_nom']}."
               ]);
        } catch (PDOException $e) { /* table msg peut ne pas exister */ }

        header("Location: officine.php?success=1");
        exit();

    } catch (Exception $e) {
        $db->rollBack();
        $error = "Erreur : " . $e->getMessage();
    }
}

$pageTitle = "Délivrance Médicament - " . APP_NAME;
include '../views/includes/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-pills"></i> Délivrance de Médicament</h1>
    <a href="officine.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Retour</a>
</div>

<div class="prescription-pharma-card">
    <div class="section">
        <h3>Patient</h3>
        <p><strong><?php echo htmlspecialchars($presc['patient_nom'] . ' ' . $presc['patient_prenom']); ?></strong></p>
    </div>
    <div class="section">
        <h3>Médicament</h3>
        <p><strong><?php echo htmlspecialchars($presc['produit_libelle']); ?></strong></p>
        <p>Code : <?php echo htmlspecialchars($presc['produit_code']); ?></p>
    </div>
    <div class="section">
        <h3>Quantité prescrite</h3>
        <p class="big-number"><?php echo $presc['quantite']; ?></p>
    </div>
    <div class="section">
        <h3>Stock Disponible</h3>
        <p class="big-number <?php echo ($presc['stock_disponible'] ?? 0) < $presc['quantite'] ? 'text-danger' : 'text-success'; ?>">
            <?php echo $presc['stock_disponible'] ?? 0; ?>
        </p>
    </div>
</div>

<div class="card">
    <div class="card-header"><h3 class="card-title">Posologie</h3></div>
    <div class="card-body">
        <p class="posologie-text"><?php echo nl2br(htmlspecialchars($presc['posologie'] ?? 'Non précisée')); ?></p>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<?php if (($presc['stock_disponible'] ?? 0) >= $presc['quantite']): ?>
    <form method="POST">
        <div class="form-actions">
            <button type="submit" name="achever" class="btn btn-success btn-lg"
                    onclick="return confirm('Confirmer la délivrance de ce médicament ?')">
                <i class="fas fa-check"></i> Délivrer et Notifier le Médecin
            </button>
        </div>
    </form>
<?php else: ?>
    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Stock insuffisant !</strong>
        <a href="requisition.php?idofficine=" class="btn btn-primary btn-sm">Créer une réquisition</a>
    </div>
<?php endif; ?>

<style>
.prescription-pharma-card {
    background:white;border-radius:12px;box-shadow:var(--shadow);padding:25px;
    margin-bottom:25px;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;
}
.prescription-pharma-card .section h3 { color:var(--primary);font-size:14px;margin-bottom:10px; }
.big-number { font-size:32px;font-weight:bold;color:var(--primary); }
.posologie-text { font-size:16px;line-height:1.8;background:var(--light);padding:20px;
    border-radius:8px;border-left:4px solid var(--primary); }
</style>

<?php include '../views/includes/footer.php'; ?>
