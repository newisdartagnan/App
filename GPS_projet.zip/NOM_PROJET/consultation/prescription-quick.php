<?php
// ============================================
// consultation/prescription-quick.php
// Prescription rapide depuis la consultation
// CORRECTION HY093 : centre_externe ajouté, acte_libelle supprimé
// ============================================
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/PrescriptionMedicale.php';
requireLogin();
if (!hasPermission('consultation')) redirect('../index.php');

header('Content-Type: application/json');

$database = new Database();
$db = $database->getConnection();
$prescription = new PrescriptionMedicale($db);

$type         = sanitizeInput($_POST['type'] ?? '');
$idsous_sejour = (int)($_POST['idsous_sejour'] ?? 0);

if (!$idsous_sejour) {
    echo json_encode(['success' => false, 'message' => 'Sous-séjour requis.']);
    exit;
}

// Nettoyage du prix (supprimer espaces insécables, FC, virgule)
$prix_brut = $_POST['prix'] ?? '0';
$prix = (float)str_replace([' ', "\xc2\xa0", 'FC', ','], ['', '', '', '.'], $prix_brut);

try {
    if ($type === 'labo' || $type === 'imagerie') {
        $data = [
            'idsous_sejour'  => $idsous_sejour,
            'idacte'         => (int)($_POST['idacte'] ?? 0),
            'idsite'         => $_SESSION['site_id'],
            'idspecialite'   => $_POST['idspecialite'] ?? null,
            'prix'           => $prix,
            'prescripteur'   => $_SESSION['user_id'],
            'urgent'         => isset($_POST['urgent']) ? 1 : 0,
            'indication'     => $_POST['indication'] ?? null,
            'type_externe'   => $_POST['type_externe'] ?? 'interne',
            'centre_externe' => $_POST['centre_externe'] ?? null,  // CORRECTION
        ];

        if (!$data['idacte']) {
            echo json_encode(['success' => false, 'message' => 'Acte requis.']);
            exit;
        }

        if ($type === 'labo') {
            $id = $prescription->prescrireLaboratoire($data);
        } else {
            $id = $prescription->prescrireImagerie($data);
        }

        echo json_encode(['success' => true, 'id' => $id, 'message' => 'Prescription créée.']);

    } elseif ($type === 'pharmacie') {
        $data = [
            'idsous_sejour' => $idsous_sejour,
            'idprodpharma'  => (int)($_POST['idprodpharma'] ?? 0),
            'quantite'      => (int)($_POST['quantite'] ?? 1),
            'posologie'     => $_POST['posologie'] ?? null,
            'prescripteur'  => $_SESSION['user_id'],
            'urgence'       => isset($_POST['urgent']) ? 1 : 0,
            'montant_total' => $prix,
        ];

        if (!$data['idprodpharma']) {
            echo json_encode(['success' => false, 'message' => 'Produit requis.']);
            exit;
        }

        $id = $prescription->prescrirePharma($data);
        echo json_encode(['success' => true, 'id' => $id, 'message' => 'Prescription pharmacie créée.']);

    } else {
        echo json_encode(['success' => false, 'message' => 'Type de prescription inconnu.']);
    }

} catch (PDOException $e) {
    error_log("Erreur prescription-quick : " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erreur base de données : ' . $e->getMessage()]);
}
