<?php
require_once '../config/config.php';
requireLogin();
if (!hasPermission('consultation')) redirect('../index.php');

$pageTitle = "Consultation - " . APP_NAME;
include '../views/includes/header.php';
?>
<div class="module-header">
    <h1><i class="fas fa-stethoscope"></i> Module Consultation</h1>
    <p>Dossiers médicaux et consultations</p>
</div>
<div class="action-cards">
    <a href="../reception/recherche-patient.php" class="action-card">
        <div class="action-icon"><i class="fas fa-search"></i></div>
        <h3>Recherche Patient</h3>
        <p>Trouver un patient</p>
    </a>
    <a href="liste.php" class="action-card">
        <div class="action-icon"><i class="fas fa-list-alt"></i></div>
        <h3>Liste du jour</h3>
        <p>Patients en attente de consultation</p>
    </a>
</div>
<?php include '../views/includes/footer.php'; ?>
