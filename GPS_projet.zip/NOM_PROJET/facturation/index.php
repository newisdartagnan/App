<?php
require_once '../config/config.php';
requireLogin();
if (!hasPermission('facturation')) redirect('../index.php');
$pageTitle = "Facturation - " . APP_NAME;
include '../views/includes/header.php';
?>
<div class="module-header">
    <h1><i class="fas fa-file-invoice-dollar"></i> Module Facturation</h1>
    <p>Gestion des factures et paiements</p>
</div>
<div class="alert alert-info"><i class="fas fa-info-circle"></i> Module en cours de développement.</div>
<?php include '../views/includes/footer.php'; ?>
