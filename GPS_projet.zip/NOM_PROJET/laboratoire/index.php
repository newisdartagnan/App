<?php
require_once '../config/config.php';
require_once '../config/database.php';
requireLogin();
if (!hasPermission('laboratoire')) redirect('../index.php');

$pageTitle = "Laboratoire - " . APP_NAME;
include '../views/includes/header.php';
?>
<div class="module-header">
    <h1><i class="fas fa-flask"></i> Module Laboratoire</h1>
    <p>Analyses biologiques et résultats</p>
</div>
<div class="action-cards">
    <a href="prescriptions.php" class="action-card">
        <div class="action-icon"><i class="fas fa-list-alt"></i></div>
        <h3>Prescriptions</h3>
        <p>Analyses en attente</p>
    </a>
    <a href="resultats.php" class="action-card">
        <div class="action-icon"><i class="fas fa-vial"></i></div>
        <h3>Résultats</h3>
        <p>Saisir les résultats</p>
    </a>
    <a href="rapports-labo.php" class="action-card">
        <div class="action-icon"><i class="fas fa-chart-bar"></i></div>
        <h3>Rapports</h3>
        <p>Statistiques et exports</p>
    </a>
</div>
<?php include '../views/includes/footer.php'; ?>
