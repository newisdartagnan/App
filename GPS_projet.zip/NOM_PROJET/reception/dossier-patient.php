<?php
require_once '../config/config.php';
require_once '../config/database.php';
requireLogin();

$database = new Database();
$db = $database->getConnection();

$idpatient = (int)($_GET['id'] ?? 0);
if (!$idpatient) redirect('recherche-patient.php');

// Patient complet
$stmt = $db->prepare("SELECT p.*,
                             c.nom  AS categorie_nom, s.nom AS societe_nom,
                             q.nom  AS quartier_nom,  co.nom AS commune_nom,
                             g.nom  AS groupe_sanguin, e.nom AS ethnie_nom, r.nom AS religion_nom
                      FROM patient p
                      LEFT JOIN categorie c  ON p.idcategorie = c.idcategorie
                      LEFT JOIN societe   s  ON p.idsociete   = s.idsociete
                      LEFT JOIN quartier  q  ON p.idquartier  = q.idquartier
                      LEFT JOIN commune   co ON q.idcommune   = co.idcommune
                      LEFT JOIN grsanguin g  ON p.idgrsanguin = g.idgrsanguin
                      LEFT JOIN ethnie    e  ON p.idethnie    = e.idethnie
                      LEFT JOIN religion  r  ON p.idreligion  = r.idreligion
                      WHERE p.idpatient = :id");
$stmt->execute([':id' => $idpatient]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$patient) redirect('recherche-patient.php');

// Séjours
$stmtS = $db->prepare("SELECT s.*, m.libelle AS motif, site.nom AS site_nom,
                               um.nom AS unite_nom
                        FROM sejour s
                        LEFT JOIN motif m ON s.idmotif = m.idmotif
                        LEFT JOIN site site ON s.idsite = site.idsite
                        LEFT JOIN sous_sejour ss ON s.idsejour = ss.idsejour
                        LEFT JOIN unite_med um ON ss.idunite_med = um.idunite_med
                        WHERE s.idpatient = :id
                        GROUP BY s.idsejour ORDER BY s.date_entree DESC");
$stmtS->execute([':id' => $idpatient]);
$sejours = $stmtS->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Dossier - " . $patient['nom'] . " " . $patient['prenom'] . " - " . APP_NAME;
include '../views/includes/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-folder-open"></i> Dossier Patient</h1>
    <div class="header-actions">
        <a href="creer-sejour.php?idpatient=<?php echo $idpatient; ?>" class="btn btn-primary">
            <i class="fas fa-door-open"></i> Nouveau Séjour
        </a>
        <a href="recherche-patient.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Retour
        </a>
    </div>
</div>

<!-- Identité -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user"></i> Identité</h3>
        <span class="badge badge-primary"><?php echo htmlspecialchars($patient['numero_dossier']); ?></span>
    </div>
    <div class="card-body">
        <div class="form-row">
            <div><strong>Nom :</strong> <?php echo htmlspecialchars($patient['nom'] . ' ' . $patient['prenom'] . ' ' . ($patient['postnom'] ?? '')); ?></div>
            <div><strong>Né(e) le :</strong> <?php echo formatDate($patient['date_naissance']); ?>
                 (<?php echo calculateAge($patient['date_naissance']); ?> ans)</div>
            <div><strong>Sexe :</strong> <?php echo $patient['sexe'] === 'M' ? 'Masculin' : 'Féminin'; ?></div>
            <div><strong>Téléphone :</strong> <?php echo htmlspecialchars($patient['telephone1'] ?? '-'); ?></div>
            <div><strong>Type :</strong>
                <span class="badge <?php echo $patient['type_patient'] === 'conventionne' ? 'badge-success' : 'badge-warning'; ?>">
                    <?php echo $patient['type_patient'] === 'conventionne' ? 'Conventionné' : 'Privé'; ?>
                </span>
            </div>
            <div><strong>Groupe sanguin :</strong> <?php echo htmlspecialchars($patient['groupe_sanguin'] ?? '-'); ?></div>
            <?php if ($patient['societe_nom']): ?>
            <div><strong>Société :</strong> <?php echo htmlspecialchars($patient['societe_nom']); ?></div>
            <?php endif; ?>
            <div><strong>Catégorie :</strong> <?php echo htmlspecialchars($patient['categorie_nom'] ?? '-'); ?></div>
        </div>
    </div>
</div>

<!-- Séjours -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-history"></i> Historique des séjours
            <span class="badge badge-secondary"><?php echo count($sejours); ?></span>
        </h3>
    </div>
    <div class="card-body">
        <?php if (empty($sejours)): ?>
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <p>Aucun séjour enregistré.</p>
                <a href="creer-sejour.php?idpatient=<?php echo $idpatient; ?>" class="btn btn-primary">
                    Créer un séjour
                </a>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>N° Séjour</th>
                            <th>Type</th>
                            <th>Date entrée</th>
                            <th>Date sortie</th>
                            <th>Unité</th>
                            <th>Motif</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sejours as $s): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($s['numero_sejour']); ?></strong></td>
                            <td><?php echo htmlspecialchars(ucfirst($s['type_sejour'] ?? '')); ?></td>
                            <td><?php echo formatDateTime($s['date_entree']); ?></td>
                            <td><?php echo $s['date_sortie'] ? formatDateTime($s['date_sortie']) : '<em>En cours</em>'; ?></td>
                            <td><?php echo htmlspecialchars($s['unite_nom'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($s['motif'] ?? '-'); ?></td>
                            <td>
                                <?php
                                $badges = ['ouvert'=>'badge-success','ferme'=>'badge-secondary','annule'=>'badge-danger'];
                                $badge  = $badges[$s['statut']] ?? 'badge-secondary';
                                ?>
                                <span class="badge <?php echo $badge; ?>"><?php echo ucfirst($s['statut']); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../views/includes/footer.php'; ?>
