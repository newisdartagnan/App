<?php
require_once '../config/config.php';
requireLogin();
if (!hasPermission('reception')) redirect('../index.php');

$pageTitle = "Réception - " . APP_NAME;
include '../views/includes/header.php';
?>
<div class="module-header">
    <h1><i class="fas fa-user-plus"></i> Module Réception</h1>
    <p>Enregistrement et gestion des patients</p>
</div>
<div class="action-cards">
    <a href="recherche-patient.php" class="action-card">
        <div class="action-icon"><i class="fas fa-search"></i></div>
        <h3>Recherche Patient</h3>
        <p>Rechercher un patient existant</p>
    </a>
    <a href="nouveau-patient.php" class="action-card">
        <div class="action-icon"><i class="fas fa-user-plus"></i></div>
        <h3>Nouveau Patient</h3>
        <p>Enregistrer un nouveau patient</p>
    </a>
    <a href="creer-sejour.php" class="action-card">
        <div class="action-icon"><i class="fas fa-door-open"></i></div>
        <h3>Créer un Séjour</h3>
        <p>Ouvrir un séjour pour un patient</p>
    </a>
</div>
<?php include '../views/includes/footer.php'; ?>
