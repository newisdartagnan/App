<?php
require_once '../config/config.php';
require_once '../config/database.php';
requireLogin();
if (!hasPermission('reception')) redirect('../index.php');

$database = new Database();
$db = $database->getConnection();

$idpatient = (int)($_GET['idpatient'] ?? 0);
if (!$idpatient) redirect('recherche-patient.php');

// Récupérer le patient
$stmt = $db->prepare("SELECT p.*, c.nom AS categorie_nom, s.nom AS societe_nom
                      FROM patient p
                      LEFT JOIN categorie c ON p.idcategorie = c.idcategorie
                      LEFT JOIN societe   s ON p.idsociete   = s.idsociete
                      WHERE p.idpatient = :id");
$stmt->execute([':id' => $idpatient]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$patient) redirect('recherche-patient.php');

// Référentiels
$motifs  = $db->query("SELECT * FROM motif  ORDER BY libelle")->fetchAll(PDO::FETCH_ASSOC);
$origines= $db->query("SELECT * FROM origine ORDER BY libelle")->fetchAll(PDO::FETCH_ASSOC);
$unites  = $db->prepare("SELECT um.*, srv.nom AS service_nom
                         FROM unite_med um
                         LEFT JOIN services srv ON um.idservices = srv.idservices
                         WHERE um.actif = 1 ORDER BY srv.nom, um.nom");
$unites->execute();
$unites  = $unites->fetchAll(PDO::FETCH_ASSOC);

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->beginTransaction();

        // Numéro de séjour
        $lastQ = $db->query("SELECT MAX(CAST(SUBSTRING(numero_sejour, 4) AS UNSIGNED)) AS last_num FROM sejour WHERE numero_sejour LIKE 'SEJ%'");
        $lastN = $lastQ->fetch(PDO::FETCH_ASSOC)['last_num'] ?? 0;
        $numero_sejour = generateNumero('SEJ', $lastN);

        $stmtS = $db->prepare("INSERT INTO sejour
            (idpatient, numero_sejour, type_sejour, anciennete, idmotif,
             date_entree, statut, idsite, idutilisateur, observation)
            VALUES
            (:idpatient, :numero_sejour, :type_sejour, :anciennete, :idmotif,
             :date_entree, 'ouvert', :idsite, :idutilisateur, :observation)");
        $stmtS->execute([
            ':idpatient'    => $idpatient,
            ':numero_sejour'=> $numero_sejour,
            ':type_sejour'  => $_POST['type_sejour'],
            ':anciennete'   => $_POST['anciennete'] ?? 'nouveau',
            ':idmotif'      => $_POST['idmotif'] ?: null,
            ':date_entree'  => $_POST['date_entree'],
            ':idsite'       => $_SESSION['site_id'],
            ':idutilisateur'=> $_SESSION['user_id'],
            ':observation'  => $_POST['observation'] ?? null,
        ]);
        $idsejour = $db->lastInsertId();

        // Sous-séjour
        $stmtSS = $db->prepare("INSERT INTO sous_sejour
            (idsejour, idunite_med, statut, date_entree)
            VALUES (:idsejour, :idunite_med, 'en_cours', :date_entree)");
        $stmtSS->execute([
            ':idsejour'   => $idsejour,
            ':idunite_med'=> $_POST['idunite_med'],
            ':date_entree'=> $_POST['date_entree'],
        ]);

        $db->commit();
        flashMessage('success', "Séjour $numero_sejour créé avec succès.");
        redirect('dossier-patient.php?id=' . $idpatient);

    } catch (PDOException $e) {
        $db->rollBack();
        $error = "Erreur : " . $e->getMessage();
    }
}

$pageTitle = "Créer un Séjour - " . APP_NAME;
include '../views/includes/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-door-open"></i> Créer un Séjour</h1>
    <a href="dossier-patient.php?id=<?php echo $idpatient; ?>" class="btn btn-outline">
        <i class="fas fa-arrow-left"></i> Retour au dossier
    </a>
</div>

<!-- Info patient -->
<div class="card" style="border-left:4px solid var(--primary)">
    <div class="card-body">
        <strong><?php echo htmlspecialchars($patient['nom'] . ' ' . $patient['prenom']); ?></strong>
        &nbsp;|&nbsp; <?php echo htmlspecialchars($patient['numero_dossier']); ?>
        &nbsp;|&nbsp; Né(e) le <?php echo formatDate($patient['date_naissance']); ?>
        &nbsp;|&nbsp;
        <span class="badge <?php echo $patient['type_patient'] === 'conventionne' ? 'badge-success' : 'badge-warning'; ?>">
            <?php echo $patient['type_patient'] === 'conventionne' ? 'Conventionné' : 'Privé'; ?>
        </span>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3 class="card-title">Informations du séjour</h3></div>
    <div class="card-body">
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label>Type de séjour *</label>
                    <select name="type_sejour" class="form-control" required>
                        <option value="consultation">Consultation</option>
                        <option value="hospitalisation">Hospitalisation</option>
                        <option value="urgence">Urgence</option>
                        <option value="chirurgie">Chirurgie</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Ancienneté</label>
                    <select name="anciennete" class="form-control">
                        <option value="nouveau">Nouveau</option>
                        <option value="ancien">Ancien</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date d'entrée *</label>
                    <input type="datetime-local" name="date_entree" class="form-control"
                           value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Motif</label>
                    <select name="idmotif" class="form-control">
                        <option value="">-- Sélectionner --</option>
                        <?php foreach ($motifs as $m): ?>
                            <option value="<?php echo $m['idmotif']; ?>"><?php echo htmlspecialchars($m['libelle']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Unité médicale *</label>
                    <select name="idunite_med" class="form-control" required>
                        <option value="">-- Sélectionner --</option>
                        <?php foreach ($unites as $u): ?>
                            <option value="<?php echo $u['idunite_med']; ?>">
                                <?php echo htmlspecialchars(($u['service_nom'] ? $u['service_nom'] . ' / ' : '') . $u['nom']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Observation</label>
                <textarea name="observation" class="form-control" rows="3" placeholder="Remarques..."></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save"></i> Créer le séjour
                </button>
            </div>
        </form>
    </div>
</div>

<?php include '../views/includes/footer.php'; ?>
